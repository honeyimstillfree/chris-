## Information

<!-- Replace with the relevant information !-->
* **Name:** [NAME]
* **Category:** [CATEGORY]

## Preview

<!-- Replace both with the badge being added -->
| Preview | Markdown Code |
|---------|---------------|
| [![GitHub](https://img.shields.io/badge/GitHub-%23121011.svg?logo=github&logoColor=white)](#) | `[![GitHub](https://img.shields.io/badge/GitHub-%23121011.svg?logo=github&logoColor=white)](#)` |